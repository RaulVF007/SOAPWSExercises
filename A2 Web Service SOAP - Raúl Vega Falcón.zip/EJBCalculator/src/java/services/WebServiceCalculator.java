/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Lab-DIS
 */
@WebService(serviceName = "WebServiceCalculator")
@Stateless()
public class WebServiceCalculator {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "factorial")
    public int factorial(@WebParam(name = "x") int x) {
        if (x == 0) return 1;
        else return (x*factorial(x-1));
    }
}

