/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservicedecimaltobinary;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lab-DIS
 */
@WebService(serviceName = "WebserviceDecimalToBinary")
public class WebserviceDecimalToBinary {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "decimalToBinary")
    public String decimalToBinary(@WebParam(name = "number") int number) {
        String numerobinario = "";
        StringBuilder ala = new StringBuilder();
	numerobinario = numerobinario + (number % 2);
        number = number / 2;
        while (number >= 2) {
            numerobinario = numerobinario + (number % 2);   
            number = number / 2;
        }
        numerobinario = numerobinario + number;
        StringBuilder cadena = ala.append(numerobinario);
        cadena = ala.reverse();
        return cadena.toString();
    }
}
