/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unitconverter;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lab-DIS
 */
@WebService(serviceName = "Converter")
public class Converter {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "celciusToFahrenheit")
    public double celciusToFahrenheit(@WebParam(name = "celcius") int celcius) {
        //TODO write your implementation code here:
        return ((celcius * 1.8) + 32);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "kilosToPounds")
    public double kilosToPounds(@WebParam(name = "kilos") int kilos) {
        //TODO write your implementation code here:
        return (kilos/2.205);
    }
}
